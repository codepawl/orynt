"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Compass, 
  Cpu, 
  Terminal, 
  FileText, 
  ChevronRight, 
  Sparkles, 
  Copy, 
  Check, 
  Layers, 
  Wind, 
  Database, 
  RefreshCw,
  Workflow,
  Search,
  BookOpen,
  ArrowRight,
  Info,
  Maximize2
} from "lucide-react";

// Raw definitions mirroring inputs.json directly.
const localInputsData = {
  "brand": {
    "name": "CodePawl",
    "vietnameseName": "Kiến Trúc Nhân",
    "description": "Vietnamese AI infrastructure and developer tooling project designed for the AI agent era. Focuses on tracing, high-performance structured memory routes, deterministic runtime cache compilation, and raw execution replay.",
    "mission": "To bind raw computational concrete with elegant mathematical ventilation, bringing high-concurrency reproducibility to complex multi-agent execution systems.",
    "foundedLocation": "Ho Chi Minh City, Vietnam"
  },
  "aesthetic": {
    "style": "Vietnamese Modernism x Restrained Brutalist Web",
    "tokens": {
      "colors": {
        "bgPrimary": "#FBFBF9",
        "bgSecondary": "#EAEAE6",
        "bgDark": "#1E1E1E",
        "borderRaw": "#333333",
        "concreteGray": "#8E8E88",
        "shadowTint": "rgba(40, 40, 36, 0.15)",
        "accentSienna": "#C85C42"
      }
    }
  },
  "ecosystem": {
    "projects": [
      {
        "id": "CachePawl",
        "name": "CachePawl",
        "purpose": "Agent Context-Aware Vector & State Cache",
        "description": "Caches semantic agent states and tool-use histories using physical location-locality and active projection. Reduces inference round-trip latencies by up to 72% via tropical routing optimization.",
        "architectureEquivalent": "Thermal Mass Louvers (Passive ventilation panels regulating local temperatures)"
      },
      {
        "id": "TracePawl",
        "name": "TracePawl",
        "purpose": "Deterministic Agent Execution Replay",
        "description": "Traces individual agent trajectory steps and external API side-effects. Facilitates exact step-by-step state recreation and deterministic replay debuggers for asynchronous agentic swarms.",
        "architectureEquivalent": "Structural Columns (Load-bearing layout keeping complex systems stable and isolated)"
      },
      {
        "id": "MemPawl",
        "name": "MemPawl",
        "purpose": "Persistent Hierarchical Memory Router",
        "description": "Combines short-term volatile buffers with deep horizontal cold storage. Implements standard vector indexing alongside traditional relational databases using hybrid query trees.",
        "architectureEquivalent": "Ventilation Bricks (Letting context filter seamlessly and securely across layered security gates)"
      },
      {
        "id": "TrainPawl",
        "name": "TrainPawl",
        "purpose": "Synthetic Swarm Fine-Tuning Engine",
        "description": "Takes TracePawl execution trajectories and compiles them into highly optimized LoRA synthetic sets to fine-tune specialized smaller models for extreme agents speed.",
        "architectureEquivalent": "Cantilever Balconies (Modular overhangs casting cooling shadows over lower floors)"
      }
    ]
  },
  "handoff": {
    "framework": "Next.js 15 App Router",
    "styling": "Tailwind CSS v4 (with PostCSS plugin)",
    "packages": ["motion", "@google/genai", "lucide-react"],
    "implementationRisks": [
      {
        "risk": "Heavy client-side SVG rendering under-performance",
        "mitigation": "Mitigated by pre-computed static coordinate paths"
      },
      {
        "risk": "Contrasting sienna accent over pure grays",
        "mitigation": "Mitigated by strict WCAG contrast validation checking"
      },
      {
        "risk": "Intricate layout overflow on ultra-small viewports",
        "mitigation": "Solved by dynamic single-column grid scaling presets"
      }
    ]
  }
};

// Architecture Styles presets for the Interactive Blueprint Generator
const ARCHITECTURE_STYLES = [
  {
    name: "General Science Library, HCMC (Thư viện Khoa học Tổng hợp HCMC)",
    architects: "Nguyễn Hữu Thiện & Bùi Quang Hanh (1971)",
    features: "High concrete stilts, rhythmic vertical fins, and geometric modular grid facades.",
    ventilationType: "Modular Rectangular Grid Slots"
  },
  {
    name: "Independence Palace (Dinh Độc Lập)",
    architects: "Ngô Viết Thụ (1966)",
    features: "Elegant bamboo-stalk shaped stone columns, majestic horizontal cantilever balconies.",
    ventilationType: "Traditional Stone Balustrade Slits"
  },
  {
    name: "Saigon Central Post Office Restrained Louvers",
    architects: "Marie-Alfred Foulhoux (19th c. modernist preservation)",
    features: "Deep solar overhangs, tall shuttered high-ventilation arches.",
    ventilationType: "Arched Steel Shutter Louvers"
  },
  {
    name: "Võ Văn Kiệt Modernist Ventilation Brick Duplex",
    architects: "Contemporary Saigon Vanguard Architect Groups",
    features: "Full-scale terracotta Breeze Brick facades with raw concrete slab framing.",
    ventilationType: "Terracotta Starflowers & Circle Blocks"
  }
];

const WORKLOAD_PRESETS = [
  "Async Customer Support Multi-Agent Swarms",
  "Deterministic High-Frequency Algorithmic Trading Bots",
  "Autonomous Code-Base Refactoring & Translation Pipelines",
  "Real-Time Surgical Patient Telemetry Monitoring Agents"
];

// Ventilation brick geometry types for the Interactive Cooling Sandbox
const BRICK_GEOMETRIES = [
  {
    id: "flower",
    name: "Hoa Cúc (Starflower)",
    vietnameseName: "Gạch Bông Gió Cúc",
    efficiencyFactor: 0.61,
    structuralStrength: "Excellent load-bearing parameters, perfect for high-weight storage frames.",
    description: "Classic circular central hub with four radiating petal-shaped cutouts. Creates complex diffused lighting.",
    svgPath: "M 12 4 A 8 8 0 0 1 12 20 A 8 8 0 0 1 12 4 M 12 8 A 4 4 0 0 0 12 16 A 4 4 0 0 0 12 8"
  },
  {
    id: "cross",
    name: "Chữ Thập (Crossed Rects)",
    vietnameseName: "Gạch Bông Gió Thập",
    efficiencyFactor: 0.94,
    structuralStrength: "Supreme passive cooling airflow, moderate structural weight thresholds.",
    description: "High-intake clean modernist perpendicular openings. Maximizes throughput. Highly brutalist.",
    svgPath: "M 6 10 H 10 V 6 H 14 V 10 H 18 V 14 H 14 V 18 H 10 V 14 H 6 Z"
  },
  {
    id: "circular",
    name: "Đồng Tiền (Circular Ring)",
    vietnameseName: "Gạch Bông Gió Tròn",
    efficiencyFactor: 0.78,
    structuralStrength: "High compression load absorption, ideal for deep-level database foundations.",
    description: "Concentric circular frames with horizontal steel tie rebar accents. Balanced shadows and security.",
    svgPath: "M 12 2 A 10 10 0 1 0 12 22 A 10 10 0 1 0 12 2 M 12 5 A 7 7 0 1 1 12 19 A 7 7 0 1 1 12 5"
  },
  {
    id: "slanted",
    name: "Mái Dốc (Louvers / Fins)",
    vietnameseName: "Khối Chớp Bê Tông",
    efficiencyFactor: 0.85,
    structuralStrength: "High solar-glare deflection, optimized for western-exposed sensory nodes.",
    description: "Diagonal solid concrete fins that shield high-frequency direct light while maintaining airflow.",
    svgPath: "M 2 6 L 22 2 L 22 8 L 2 12 Z M 2 14 L 22 10 L 22 16 L 2 20 Z"
  }
];

export default function Home() {
  // Brand Brief Inputs Data Edit State
  const [inputsData, setInputsData] = useState(localInputsData);
  const [showMetadataRaw, setShowMetadataRaw] = useState(false);
  const [copiedText, setCopiedText] = useState("");

  // High Density Active Accent Theme State - defaults to 'moss'
  const [accentTheme, setAccentTheme] = useState<"moss" | "sienna">("moss");

  const isMoss = accentTheme === "moss";
  const accentBg = isMoss ? "bg-[#4A5D4E]" : "bg-[#C85C42]";
  const accentText = isMoss ? "text-[#4A5D4E]" : "text-[#C85C42]";
  const accentBorder = isMoss ? "border-[#4A5D4E]" : "border-[#C85C42]";
  const accentHoverBg = isMoss ? "hover:bg-[#4A5D4E]" : "hover:bg-[#e06c52]";
  const accentHoverText = isMoss ? "hover:text-[#4A5D4E]" : "hover:text-[#C85C42]";
  const shadowClass = isMoss ? "shadow-moss-sm" : "shadow-sienna-sm";
  const ringFocusClass = isMoss ? "focus:border-[#4A5D4E]" : "focus:border-[#C85C42]";
  const bgBadge = isMoss ? "bg-[#4A5D4E]/10 border-[#4A5D4E]" : "bg-[#C85C42]/10 border-[#C85C42]";

  // Saigon Time State (Local Time is 2026-06-03 UTC, which would be 22:30:08 Saigon time)
  const [saigonTime, setSaigonTime] = useState("22:30:08 GMT+7");

  useEffect(() => {
    // Implement standard live clock updater
    const timer = setInterval(() => {
      const gmt7 = new Date(new Date().getTime() + 7 * 60 * 60 * 1000);
      const hours = String(gmt7.getUTCHours()).padStart(2, "0");
      const minutes = String(gmt7.getUTCMinutes()).padStart(2, "0");
      const seconds = String(gmt7.getUTCSeconds()).padStart(2, "0");
      setSaigonTime(`${hours}:${minutes}:${seconds} GMT+7`);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Sandbox Structural Loom State
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);
  const [activeSegmentFilter, setActiveSegmentFilter] = useState<"all" | "concrete" | "ventilation">("all");
  const [simulationSpeed, setSimulationSpeed] = useState<"standard" | "high" | "overclock">("standard");

  // Bricks Cooling System Playground State
  const [selectedBrickType, setSelectedBrickType] = useState(BRICK_GEOMETRIES[1]); // Default to crossed rects

  // Dynamic cooling metrics derived calculation
  const efficiency = selectedBrickType.efficiencyFactor;
  const chassisTemp = Math.round(52 - (efficiency * 16));
  const nodeAirflowPercentage = Math.round(efficiency * 100);

  // AI-Powered Modernist Blueprint Synthesis Form State
  const [selectedWorkload, setSelectedWorkload] = useState(WORKLOAD_PRESETS[0]);
  const [customWorkloadInput, setCustomWorkloadInput] = useState("");
  const [selectedArchStyle, setSelectedArchStyle] = useState(ARCHITECTURE_STYLES[0].name);
  const [customStyleInput, setCustomStyleInput] = useState("");

  const [synthesizing, setSynthesizing] = useState(false);
  const [synthesisResult, setSynthesisResult] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState("");

  // Handle API Gemini Brief Request
  const handleSynthesizeBlueprint = async () => {
    setSynthesizing(true);
    setErrorMessage("");
    try {
      const finalWorkload = customWorkloadInput.trim() || selectedWorkload;
      const finalStyle = customStyleInput.trim() || selectedArchStyle;

      const res = await fetch("/api/gemini/brief", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          workload: finalWorkload,
          architectureStyle: finalStyle
        }),
      });

      if (!res.ok) {
        throw new Error("HTTP error " + res.status);
      }
      const data = await res.json();
      setSynthesisResult(data);
    } catch (err: any) {
      console.error(err);
      setErrorMessage("Could not contact server-side Gemini system. Loaded default fallback architecture layout safely.");
      // Soft graceful fallback setup
      setSynthesisResult({
        topologyAnalogy: "Utilizes clean horizontal concrete shade-fins corresponding to VO VAN KIET boulevard designs. The structure acts as systemic flow dividers keeping traces organized.",
        componentsRecommendation: [
          {
            component: "CachePawl",
            actionPlan: "Construct modular, decentralized memory louvers along regional edge clusters to catch volatile query waves.",
            coolingAnalogy: "Deep architectural overhang shadows keeping chips protected from peak overhead latencies."
          },
          {
            component: "TracePawl",
            actionPlan: "Establish a high-durability continuous playback ledger for trace records inside raw monolithic block structures.",
            coolingAnalogy: "Like vertical high-tensile load-bearing concrete pillars."
          }
        ],
        sampleYamlConfig: "version: \"2.0\"\ncluster:\n  location: saigon_district_3\n  modernist_cooling:\n    mode: passive_draft\n    fin_angle_deg: 45\n    louver_efficiency: 0.88\ncomponents:\n  - service: CachePawl\n    shading_index: 0.95\n    max_concurrency_threads: 256\n  - service: TracePawl\n    monolithic_storage: raw_s3_solid\n",
        latencySavingSec: 0.82
      });
    } finally {
      setSynthesizing(false);
    }
  };

  // Helper trigger copy
  const handleCopyClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(""), 2000);
  };

  return (
    <main className="min-h-screen bg-[#F5F2ED] font-sans text-[#141414] leading-relaxed relative overflow-hidden flex flex-col items-center border-t-8 md:border-[10px] border-[#141414] transition-all">
      
      {/* Decorative Tropical Solar Shadow casting across the entire background page */}
      <div className="absolute top-0 right-0 w-[45vw] h-[100vh] bg-gradient-to-bl from-[rgba(20,20,20,0.03)] to-transparent pointer-events-none transform skew-x-12 origin-top-right z-0" />
      <div className="absolute top-[120vh] left-0 w-[35vw] h-[80vh] bg-gradient-to-tr from-[rgba(20,20,20,0.02)] to-transparent pointer-events-none transform -skew-y-12 origin-top-left z-0" />

      {/* RAW EDITORIAL TOP NAV BAR */}
      <header className="w-full border-b-2 border-[#141414] bg-[#EAE7E1] sticky top-0 z-50">
        <div className="max-w-[1360px] mx-auto px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-baseline gap-3">
            <span className={`font-mono text-xs text-white ${accentBg} px-2 py-0.5 tracking-widest font-bold transition-all duration-200`}>HCMC</span>
            <span className="font-sans font-black tracking-tighter text-2xl text-[#141414]">CODEPAWL</span>
            <span className="font-mono text-[10px] text-neutral-500 border-l border-neutral-500/30 pl-3 tracking-wider uppercase">
              Kiến Trúc Nhân — Modernist Agent Core
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            {/* Real-time Theme Accent Switcher as requested by High Density design patterns */}
            <div className="flex items-center gap-1 bg-[#D4D1CA]/65 border border-[#141414] p-0.5 rounded-none shadow-sm">
              <button 
                onClick={() => setAccentTheme("moss")} 
                className={`px-2 py-0.5 text-[9px] uppercase tracking-wider transition-all cursor-pointer ${accentTheme === "moss" ? "bg-[#4A5D4E] text-white font-bold" : "text-[#141414] hover:bg-[#F5F2ED]/50"}`}
              >
                Moss Green
              </button>
              <button 
                onClick={() => setAccentTheme("sienna")} 
                className={`px-2 py-0.5 text-[9px] uppercase tracking-wider transition-all cursor-pointer ${accentTheme === "sienna" ? "bg-[#C85C42] text-white font-bold" : "text-[#141414] hover:bg-[#F5F2ED]/50"}`}
              >
                Sienna Red
              </button>
            </div>

            <div className="h-4 w-px bg-neutral-400/30 hidden md:block" />

            <div className={`flex items-center gap-2 ${accentText} transition-all duration-200`}>
              <span className={`w-2 h-2 rounded-full ${accentBg} animate-pulse`} />
              <span className="font-bold">STABLE WORKSPACE</span>
            </div>
            
            <div className="h-4 w-px bg-neutral-400/30 hidden sm:block" />
            <div className="hidden sm:block text-[#141414]">
              SAIGON TIME: <span className="font-bold underline">{saigonTime}</span>
            </div>
            <div className="h-4 w-px bg-neutral-400/30" />
            <a 
              href="#sandbox" 
              className="px-3 py-1 bg-transparent hover:bg-[#141414] hover:text-white border border-[#141414] transition-all duration-200 font-bold"
            >
              RUN PROTOTYPE
            </a>
          </div>
        </div>
      </header>

      {/* CORE WRAPPED CONTENT */}
      <div className="w-full max-w-[1360px] px-6 py-8 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 z-10">
        
        {/* LEFT COLUMN: PRIMARY VISUAL LANDING INTERACTIVE PROTOTYPE (8 COLS) */}
        <section className="lg:col-span-8 flex flex-col gap-12">
          
          {/* HERO BANNER - Sinuous spacing, concrete columns layout */}
          <div className="border-4 border-[#141414] bg-[#F5F2ED] p-8 md:p-12 relative overflow-hidden shadow-tropical">
            
            {/* Raw Concrete Pillar Lines Background */}
            <div className="absolute inset-y-0 right-10 w-[120px] border-l border-r border-[#141414]/5 hidden md:block facade-stripes" />

            {/* Accent colored top-corner architectural projection block */}
            <div className={`absolute top-0 right-0 w-32 h-32 ${accentBg} text-white p-4 flex flex-col justify-between items-end select-none font-mono transition-all duration-200`}>
              <span className="text-[10px] tracking-widest leading-none">GRID-01</span>
              <span className="text-4xl font-black">2026</span>
            </div>

            <div className="max-w-[580px] flex flex-col gap-6 relative z-10">
              <div className="text-xs uppercase tracking-widest font-mono text-neutral-500 flex items-center gap-2">
                <Compass className={`w-4 h-4 ${accentText} transition-all duration-200`} />
                <span>Vietnamese Modernism (1960s-Present) × Brutalist Web</span>
              </div>

              <h1 className="font-sans font-black text-4xl md:text-6xl tracking-tight text-[#141414] leading-[1.05]">
                Concrete-Core AI Agent Runtimes.
              </h1>

              <p className="font-sans text-neutral-700 text-base md:text-lg">
                CodePawl is developer-centric infrastructure engineered for the AI agent era. We design highly concurrent systems using a structural metaphor: binding raw state concrete with highly-ventilated mathematical memory pipelines.
              </p>

              {/* Quick Metadata Indicator Badge */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 border-t border-b border-[#141414] py-4 mt-2 text-xs font-mono">
                <div>
                  <span className="text-neutral-500 block">SAIGON NODE</span>
                  <span className="font-bold">v32_Delta_HCMC</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">PASSIVE CHASSIS</span>
                  <span className={`font-bold ${accentText} transition-all duration-200`}>Crossed Breeze Louvers</span>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <span className="text-neutral-500 block">ACTIVE SUBSYSETMS</span>
                  <span className="font-bold">Cache / Trace / Mem / Train</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mt-4">
                <a 
                  href="#sandbox" 
                  className={`px-6 py-3 bg-[#141414] text-white ${accentHoverBg} transition-colors font-mono text-sm shadow-tropical-sm flex items-center gap-2`}
                >
                  <span>Interactive Control Sandbox</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
                <a 
                  href="#blueprint-generator" 
                  className="px-6 py-3 bg-[#E0DDD7] text-[#141414] hover:bg-[#141414] hover:text-white transition-all font-mono text-sm border-2 border-[#141414]"
                >
                  Synthesize Custom Blueprint
                </a>
              </div>
            </div>
          </div>

          {/* DYNAMIC SECTION 1: INTERACTIVE PLATFORM LOOM (THE SYSTEMS CORE) */}
          <div id="sandbox" className="border-4 border-[#141414] bg-[#E0DDD7] p-6 md:p-8 relative shadow-tropical">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 pb-4 border-b border-[#141414]">
              <div>
                <span className="font-mono text-xs text-white bg-[#141414] px-2 py-0.5 tracking-wider uppercase">Platform Sandbox</span>
                <h3 className="font-sans font-black text-2xl tracking-tight text-[#141414] mt-1">The Concrete Execution Loom</h3>
                <p className="text-xs text-neutral-600 mt-1">Stack and simulate high-efficiency modernist agent execution modules.</p>
              </div>

              {/* Simulation Speeds & Segment Filters Controls */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="bg-[#F5F2ED] border border-[#141414] p-1 flex gap-1 text-[10px] font-mono shadow-sm">
                  {(["all", "concrete", "ventilation"] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setActiveSegmentFilter(f)}
                      className={`px-2 py-0.5 uppercase transition-all cursor-pointer ${
                        activeSegmentFilter === f 
                          ? `${accentBg} text-white font-bold` 
                          : "text-neutral-500 hover:text-black"
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>

                <div className="bg-[#F5F2ED] border border-[#141414] p-1 flex gap-1 text-[10px] font-mono shadow-sm">
                  {(["standard", "high", "overclock"] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setSimulationSpeed(s)}
                      className={`px-2 py-0.5 uppercase transition-all cursor-pointer ${
                        simulationSpeed === s 
                          ? "bg-[#141414] text-white font-bold" 
                          : "text-neutral-500 hover:text-black"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Sandbox Module Grid Layout */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
              
              {/* Stack View Column (4 Cols) */}
              <div className="md:col-span-5 flex flex-col justify-between gap-4">
                <div className="text-xs font-mono text-concrete-gray mb-1 flex justify-between">
                  <span>DEPLOYED ENGINE STACK</span>
                  <span>(CLICK BLOCKS TO INSPECT)</span>
                </div>

                {/* Stacking Towers simulated by concrete slab bars */}
                <div className="flex flex-col gap-3">
                  {inputsData.ecosystem.projects.map((proj, idx) => {
                    const isHovered = hoveredProject === proj.id;
                    const isConcreteType = proj.id === "TracePawl" || proj.id === "TrainPawl";
                    const isFiltered = activeSegmentFilter === "all" || 
                      (activeSegmentFilter === "concrete" && isConcreteType) ||
                      (activeSegmentFilter === "ventilation" && !isConcreteType);

                    return (
                      <button
                        key={proj.id}
                        onMouseEnter={() => setHoveredProject(proj.id)}
                        onClick={() => setHoveredProject(proj.id)}
                        className={`w-full text-left border-2 border-[#141414] p-4 relative transition-all duration-200 transform ${
                          isHovered 
                            ? `bg-[#F5F2ED] scale-[1.02] ${shadowClass}` 
                            : "bg-[#D4D1CA]/80 hover:bg-[#F5F2ED]"
                        } ${!isFiltered ? "opacity-30" : "opacity-100"}`}
                        style={{
                          borderLeftWidth: isHovered ? "8px" : "2px"
                        }}
                      >
                        {/* Side Ventilation indicator box */}
                        <div className="absolute right-0 top-0 bottom-0 w-8 border-l border-[#141414] bg-[#141414] flex flex-col justify-around items-center py-2 text-[8px] font-mono text-neutral-400 text-center overflow-hidden">
                          {isConcreteType ? (
                            <>
                              <div className="w-4 h-1 bg-neutral-500" />
                              <div className="w-4 h-1 bg-neutral-500" />
                              <div className="w-4 h-1 bg-neutral-500" />
                            </>
                          ) : (
                            <>
                              <span className="text-white text-[7px] animate-pulse" style={{ animationDuration: simulationSpeed === "standard" ? "1s" : simulationSpeed === "high" ? "0.5s" : "0.2s" }}>◌</span>
                              <span className="text-white text-[7px] animate-pulse">◌</span>
                              <span className={`${accentText} text-[7px] animate-bounce`}>●</span>
                            </>
                          )}
                        </div>

                        <div className="pr-6">
                          <div className="font-mono text-[10px] text-neutral-500 font-bold uppercase tracking-wider">
                            0{idx + 1} {" // "} {proj.id}
                          </div>
                          <h4 className="font-sans font-extrabold text-lg text-[#141414]">{proj.name}</h4>
                          <span className={`font-mono text-[9px] block ${accentText} font-semibold mt-0.5 uppercase tracking-wide transition-all duration-200`}>
                            {proj.purpose}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="p-3 bg-[#F5F2ED] border border-[#141414] font-mono text-[10px] text-neutral-600">
                  <span className="font-bold text-[#141414] block mb-1">💡 Architecture Tip:</span>
                  Passively ventilated architectures (modular louvers) reduce chip degradation under peak concurrent agent loops by avoiding thermal state traps.
                </div>
              </div>

              {/* Dynamic State Telemetry Display Column (7 Cols) */}
              <div className="md:col-span-7 border-2 border-[#141414] bg-[#141414] text-[#F5F2ED] p-6 flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 select-none pointer-events-none font-mono text-[80px] font-black text-white/[0.02] tracking-tighter leading-none uppercase">
                  RAW CORE
                </div>

                {/* Subsystem Inspection Detail Panels */}
                <div className="relative z-10 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-4 border-b border-white/10 pb-2">
                      <span className="font-mono text-xs text-neutral-400 flex items-center gap-1.5">
                        <Terminal className={`w-3.5 h-3.5 ${accentText}`} /> 
                        CORE TELEMETRY LOGS
                      </span>
                      <span className="text-[10px] font-mono bg-white/10 px-2 py-0.5 text-white">
                        ACTIVE: {hoveredProject || "CachePawl"}
                      </span>
                    </div>

                    {/* Dynamic Metadata Render depending on system segment selected */}
                    {(() => {
                      const activeProjId = hoveredProject || "CachePawl";
                      const proj = inputsData.ecosystem.projects.find(p => p.id === activeProjId);
                      if (!proj) return null;

                      return (
                        <div className="flex flex-col gap-3">
                          <div>
                            <h5 className="font-sans font-black text-xl text-[#F5F2ED] tracking-tight">{proj.name}</h5>
                            <span className={`${accentText} text-xs font-mono font-bold tracking-wider uppercase block mt-0.5 transition-all duration-200`}>
                              {proj.purpose}
                            </span>
                          </div>

                          <p className={`text-xs text-neutral-300 leading-normal bg-neutral-900 p-3 italic border-l-2 ${accentBorder} transition-all duration-200`}>
                            &quot;{proj.description}&quot;
                          </p>

                          <div className="grid grid-cols-2 gap-3 mt-1 text-xs">
                            <div className="bg-neutral-900 p-2.5 border border-white/5">
                              <span className="text-neutral-400 block text-[10px] uppercase font-mono">Modernist Equal</span>
                              <span className="font-sans font-bold text-white block mt-0.5 leading-snug">{proj.architectureEquivalent}</span>
                            </div>
                            <div className="bg-neutral-900 p-2.5 border border-white/5 flex flex-col justify-between">
                              <div>
                                <span className="text-neutral-400 block text-[10px] uppercase font-mono">Chassis Cooling</span>
                                <span className={`font-mono font-bold ${accentText} block mt-0.5`}>
                                  {proj.id === "CachePawl" || proj.id === "MemPawl" ? "PASSIVE DRAFT" : "RAW MASS"}
                                </span>
                              </div>
                              <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden mt-1">
                                <div className={`${accentBg} h-full transition-all duration-200`} style={{ width: proj.id === "CachePawl" ? "85%" : proj.id === "MemPawl" ? "90%" : "30%" }} />
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Telemetry Mock Stream Output based on simulation details */}
                  <div className="mt-4 pt-4 border-t border-white/10">
                    <div className="text-[10px] font-mono text-neutral-400 flex justify-between mb-1.5">
                      <span>TRAJECTORY VECTOR STREAM</span>
                      <span className="animate-ping font-black font-mono text-emerald-400">● LIVE</span>
                    </div>

                    <div className="bg-neutral-950 p-3 rounded font-mono text-[10px] text-neutral-400 flex flex-col gap-1 overflow-x-auto select-all max-h-[110px] overflow-y-auto">
                      <div><span className={`${accentText}`}>[INIT]</span> code_pawl_root::boot_chassis_modernist_cooling() ... OK</div>
                      <div><span className="text-neutral-400">[CALC]</span> thermal_concurrency_load_capacity: <span className="text-white">400 req/sec</span></div>
                      <div><span className="text-cyan-400">[INFO]</span> active_louver_cooling: <span className="text-white">TRUE</span> (using {selectedBrickType.name})</div>
                      <div><span className="text-emerald-400">[CORE]</span> {hoveredProject || "CachePawl"} routing trace context trajectory hashes ...</div>
                      <div className="text-white truncate">SHA3-256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855</div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* DYNAMIC SECTION 2: THE VENTILATION BRICK INTAKE & SIMULATED THERMALS */}
          <div className="border-4 border-[#141414] bg-[#F5F2ED] p-6 md:p-8 relative shadow-tropical">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
              
              {/* Graphic representation / Selected Vent display (5 Cols) */}
              <div className="md:col-span-5 flex flex-col items-center gap-4 bg-[#E0DDD7] p-6 border-2 border-[#141414] relative">
                
                {/* Visual grid illustration of gạch bông gió */}
                <div className="grid grid-cols-3 gap-3 w-full max-w-[240px]">
                  {Array.from({ length: 9 }).map((_, i) => (
                    <div 
                      key={i} 
                      className={`aspect-square border-2 border-[#141414] flex items-center justify-center transition-all ${
                        i === 4 ? `bg-[#4A5D4E]/10` : "bg-white"
                      }`}
                    >
                      <svg viewBox="0 0 24 24" className={`w-8 h-8 ${i === 4 ? accentText : "text-[#141414]"}`}>
                        <path 
                          d={selectedBrickType.svgPath} 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2.5" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                        />
                      </svg>
                    </div>
                  ))}
                </div>

                <div className="text-center">
                  <span className={`text-[10px] font-mono ${accentText} font-black uppercase tracking-widest block transition-all duration-200`}>ACTIVE GRILLE</span>
                  <p className="font-sans font-black text-lg text-[#141414]">{selectedBrickType.vietnameseName}</p>
                  <p className="text-xs text-neutral-500 mt-0.5">{selectedBrickType.name} Pattern geometry</p>
                </div>
              </div>

              {/* Selection list and interactive metrics adjustment panel (7 Cols) */}
              <div className="md:col-span-7 flex flex-col justify-between gap-6">
                <div>
                  <span className="font-mono text-xs text-white bg-[#141414] px-2 py-0.5 tracking-wider uppercase">Cooling Interface</span>
                  <h3 className="font-sans font-black text-2xl tracking-tight text-[#141414] mt-1">Gạch Bông Gió Intake Engine</h3>
                  <p className="text-xs text-neutral-600 mt-1">
                    Select distinct breeze block architectures below. Modernist ventilation geometries modulate air volume flow, dynamically cooling multi-agent memory routers passively.
                  </p>
                </div>

                {/* Selection list blocks */}
                <div className="grid grid-cols-2 gap-3">
                  {BRICK_GEOMETRIES.map((gObj) => {
                    const isSelected = selectedBrickType.id === gObj.id;
                    return (
                      <button
                        key={gObj.id}
                        onClick={() => setSelectedBrickType(gObj)}
                        className={`text-left p-3 border-2 border-[#141414] rounded-none transition-all duration-150 flex items-center gap-3 cursor-pointer ${
                          isSelected 
                            ? `${accentBg} text-white` 
                            : "bg-[#D4D1CA]/80 text-[#141414] hover:bg-[#E0DDD7]"
                        }`}
                      >
                        <svg viewBox="0 0 24 24" className="w-6 h-6 flex-shrink-0">
                          <path 
                            d={gObj.svgPath} 
                            fill="none" 
                            stroke="currentColor" 
                            strokeWidth="2.5" 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                          />
                        </svg>
                        <div className="leading-none overflow-hidden">
                          <span className="text-[10px] font-mono font-bold uppercase tracking-wider block opacity-70">
                            EFF: {(gObj.efficiencyFactor * 100).toFixed(0)}%
                          </span>
                          <span className="font-sans font-extrabold text-xs truncate block mt-0.5">{gObj.name}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Simulated Telemetry bar dials */}
                <div className="grid grid-cols-2 gap-4 mt-1 border-t border-[#141414]/15 pt-4">
                  <div className="bg-[#E0DDD7] p-3 border border-[#141414]">
                    <span className="text-[10px] font-mono text-neutral-500 block uppercase">Node Temperature</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="font-sans font-black text-2xl text-[#141414]">{chassisTemp}°C</span>
                      <span className="text-xs text-neutral-500 font-mono">/ OPTIMAL</span>
                    </div>
                    <div className="w-full bg-neutral-300/60 h-1.5 mt-2">
                      <div className="bg-[#141414] h-full transition-all duration-300" style={{ width: `${(chassisTemp / 60) * 100}%` }} />
                    </div>
                  </div>

                  <div className="bg-[#E0DDD7] p-3 border border-[#141414]">
                    <span className="text-[10px] font-mono text-neutral-500 block uppercase">Airflow Efficiency</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className={`font-sans font-black text-2xl ${accentText} transition-all duration-200`}>{nodeAirflowPercentage}%</span>
                      <span className={`text-xs ${accentText} font-mono transition-all duration-200`}>COOLED</span>
                    </div>
                    <div className="w-full bg-neutral-300/60 h-1.5 mt-2">
                      <div className={`${accentBg} h-full transition-all duration-300`} style={{ width: `${nodeAirflowPercentage}%` }} />
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* DYNAMIC SECTION 3: THE BLUEPRINT SYNTHESIS (GEMINI-POWERED FORM CORE) */}
          <div id="blueprint-generator" className="border-4 border-[#141414] bg-[#141414] text-[#F5F2ED] p-6 md:p-8 relative shadow-tropical">
            <div className="relative z-10 max-w-[620px] flex flex-col gap-4 mb-6">
              <span className={`font-mono text-xs text-white ${accentBg} w-fit px-2 py-0.5 tracking-wider uppercase transition-all duration-200`}>
                COOPERATIVE SERVER ENGINE
              </span>
              <h3 className="font-sans font-black text-3xl tracking-tight text-white leading-tight">
                Synthesize Architectural Agent Blueprints.
              </h3>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Connect your specific developer workloads with traditional Vietnamese Modernist design structures. Our backend Gemini system maps latency limits, modular alignments, and cooling louvers based on raw mathematical geometry.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              
              {/* Form Side Controls (5 Cols) */}
              <div className="md:col-span-5 bg-neutral-900 border border-white/10 p-5 flex flex-col gap-4 z-10">
                
                {/* Selection 1: Workload */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest font-bold">1. Select Target Workload</label>
                  <select 
                    value={selectedWorkload}
                    onChange={(e) => {
                      setSelectedWorkload(e.target.value);
                      setCustomWorkloadInput("");
                    }}
                    className={`w-full bg-neutral-950 border border-white/20 p-2.5 text-xs text-white font-mono focus:outline-none ${ringFocusClass} transition-all duration-150`}
                  >
                    {WORKLOAD_PRESETS.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                  <input 
                    type="text" 
                    placeholder="Or type custom agent workload..."
                    value={customWorkloadInput}
                    onChange={(e) => setCustomWorkloadInput(e.target.value)}
                    className={`w-full bg-neutral-950 border border-white/20 p-2.5 text-xs text-white font-mono mt-1.5 placeholder-neutral-650 focus:outline-none ${ringFocusClass} transition-all duration-150`}
                  />
                </div>

                {/* Selection 2: Style */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest font-bold">2. Select Vietnamese Architectural Style</label>
                  <select 
                    value={selectedArchStyle}
                    onChange={(e) => {
                      setSelectedArchStyle(e.target.value);
                      setCustomStyleInput("");
                    }}
                    className={`w-full bg-neutral-950 border border-white/20 p-2.5 text-xs text-white font-mono focus:outline-none ${ringFocusClass} transition-all duration-150`}
                  >
                    {ARCHITECTURE_STYLES.map((style) => (
                      <option key={style.name} value={style.name}>{style.name}</option>
                    ))}
                  </select>
                  <input 
                    type="text" 
                    placeholder="Or enter custom building / style..."
                    value={customStyleInput}
                    onChange={(e) => setCustomStyleInput(e.target.value)}
                    className={`w-full bg-neutral-950 border border-white/20 p-2.5 text-xs text-white font-mono mt-1.5 placeholder-neutral-650 focus:outline-none ${ringFocusClass} transition-all duration-150`}
                  />
                </div>

                {/* Action button */}
                <button
                  onClick={handleSynthesizeBlueprint}
                  disabled={synthesizing}
                  className={`w-full py-3 ${accentBg} ${accentHoverBg} text-white font-mono text-xs font-bold transition-all flex items-center justify-center gap-2 mt-2 disabled:bg-neutral-850 disabled:text-neutral-500 cursor-pointer`}
                >
                  {synthesizing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>SYNTHESIZING CONCRETE LOOM...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>SYNTHESIZE AGENT BLUEPRINT</span>
                    </>
                  )}
                </button>

                {errorMessage && (
                  <p className={`text-[10px] font-mono ${accentText} leading-normal`}>{errorMessage}</p>
                )}
              </div>

              {/* Dynamic Results Display Area (7 Cols) */}
              <div className="md:col-span-7 bg-neutral-950 border-2 border-white/10 p-6 min-h-[340px] flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-2 right-2 flex items-center gap-2 select-none z-0">
                  <Cpu className="w-16 h-16 text-white/[0.01] pointer-events-none" />
                </div>

                <AnimatePresence mode="wait">
                  {synthesizing ? (
                    <motion.div 
                      key="loader"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex-1 flex flex-col items-center justify-center gap-4 text-center my-12"
                    >
                      <div className="relative">
                        <div className={`w-12 h-12 rounded-none border-2 border-white/10 ${accentTheme === "moss" ? "border-t-[#4A5D4E]" : "border-t-[#C85C42]"} animate-spin`} />
                        <div className="absolute inset-0 flex items-center justify-center text-[10px] font-mono text-white">CP</div>
                      </div>
                      <div className="flex flex-col gap-1 max-w-[320px]">
                        <span className="font-mono text-xs text-white tracking-widest font-extrabold uppercase animate-pulse">GENERATING MOUNTED MATRIX</span>
                        <span className="text-[10px] text-neutral-400">Running Gemini 3.5 Flash structural model for tropical system analysis...</span>
                      </div>
                    </motion.div>
                  ) : synthesisResult ? (
                    <motion.div 
                      key="result"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex flex-col gap-5 z-10 flex-1 justify-between"
                    >
                      <div>
                        {/* Selected Header Info */}
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1.5 border-b border-white/10 pb-3">
                          <div>
                            <span className="text-[9px] font-mono text-neutral-400 block uppercase">WORKLOAD CONFIGURATION</span>
                            <span className="font-sans font-black text-sm text-white">
                              {customWorkloadInput.trim() || selectedWorkload}
                            </span>
                          </div>
                          
                          {/* Latency saved ticker badge */}
                          <div className={`${bgBadge} border px-3 py-1 text-right flex flex-col leading-none`}>
                            <span className="text-[8px] font-mono text-neutral-400 uppercase">LATENCY SHIELD</span>
                            <span className={`font-mono font-black text-sm ${accentText} mt-0.5`}>-{synthesisResult.latencySavingSec || 0.74}s SLA</span>
                          </div>
                        </div>

                        {/* Text description */}
                        <div className="mt-4">
                          <span className={`text-[9px] font-mono ${accentText} tracking-wider uppercase block font-bold mb-1`}>
                            COUPLED MODERN STYLE ANALOGY:
                          </span>
                          <p className={`text-xs text-neutral-300 leading-relaxed italic bg-white/[0.02] p-3 border-l-2 ${accentBorder}`}>
                            &quot;{synthesisResult.topologyAnalogy}&quot;
                          </p>
                        </div>

                        {/* Recommended deployment parts */}
                        <div className="mt-4 flex flex-col gap-2">
                          <span className="text-[9px] font-mono text-neutral-400 tracking-wider uppercase block">RECOMMENDED SUBCOMPONENTS DEPLOYMENT PLAN</span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {synthesisResult.componentsRecommendation?.slice(0, 2).map((rec: any, i: number) => (
                              <div key={i} className="bg-neutral-900 p-3 border border-white/5">
                                <span className={`font-mono text-[10px] ${accentText} block font-extrabold`}>{rec.component} deployment</span>
                                <p className="text-[10px] text-neutral-200 mt-1">{rec.actionPlan}</p>
                                <span className="text-[9px] text-neutral-400 block mt-2 font-serif italic">☘ {rec.coolingAnalogy}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Code section */}
                      <div className="mt-4 pt-4 border-t border-white/10">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[9px] font-mono text-concrete-gray uppercase">GENERATED CODEPAWL_CONFIG.YAML</span>
                          <button
                            onClick={() => handleCopyClipboard(synthesisResult.sampleYamlConfig, "yaml")}
                            className="bg-neutral-900 border border-white/10 hover:border-white/30 text-white font-mono text-[9px] px-2 py-1 flex items-center gap-1 transition-all"
                          >
                            {copiedText === "yaml" ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span>COPIED CONFIG</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>COPY YAML</span>
                              </>
                            )}
                          </button>
                        </div>
                        <pre className="text-[9px] font-mono bg-neutral-900 p-3 text-emerald-400 border border-white/5 whitespace-pre-wrap max-h-[140px] overflow-y-auto">
                          {synthesisResult.sampleYamlConfig}
                        </pre>
                      </div>

                    </motion.div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center gap-2 text-center py-12">
                      <Layers className="w-10 h-10 text-concrete-gray opacity-45" />
                      <span className="font-mono text-xs text-concrete-gray">NO BLUEPRINT SYNTHESIZED YET</span>
                      <p className="text-[10px] text-neutral-400 max-w-[240px] leading-relaxed mx-auto">
                        Alter target setup selections and hit the synthesis button to launch Gemini analysis.
                      </p>
                    </div>
                  )}
                </AnimatePresence>

              </div>

            </div>
          </div>

          {/* DYNAMIC SECTION 4: THE TECHNICAL PASSIVE-COOLING ILLUSTRATION CANVAS */}
          <div className="border-4 border-[#141414] bg-[#E0DDD7] p-6 md:p-8 relative shadow-tropical">
            <div>
              <span className="font-mono text-xs text-white bg-[#141414] px-2 py-0.5 tracking-wider uppercase">ARCHITECTURAL SCHEMATIC</span>
              <h3 className="font-sans font-black text-2xl tracking-tight text-[#141414] mt-1">Tropical Cooling Tower Cross-Section</h3>
              <p className="text-xs text-neutral-600 mt-1 max-w-[580px] mb-6">
                A mathematical representation of passive tropical heat deflection overlaid onto sequential memory layers of the CodePawl runtime. Vertical concrete tension struts divert seismic processing spikes.
              </p>
            </div>

            {/* Pristine Responsive SVG Diagram */}
            <div className="w-full bg-[#F5F2ED] p-4 border border-[#141414] flex justify-center shadow-inner">
              <svg viewBox="0 0 800 320" className="w-full max-h-[280px] select-none text-[#141414]" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Horizontal Baseline Earth Ground */}
                <line x1="20" y1="280" x2="780" y2="280" stroke="#141414" strokeWidth="3" />
                
                {/* Geological Bedrock Anchor Line */}
                <line x1="20" y1="300" x2="780" y2="300" stroke="#141414" strokeWidth="1" strokeDasharray="6 4" />
                
                {/* Vertical Massive Modernist Concrete Pillars */}
                <rect x="80" y="40" width="30" height="240" fill="#E0DDD7" stroke="#141414" strokeWidth="2.5" />
                <rect x="240" y="40" width="12" height="240" fill="#E0DDD7" stroke="#141414" strokeWidth="1.5" />
                <rect x="270" y="40" width="12" height="240" fill="#E0DDD7" stroke="#141414" strokeWidth="1.5" />
                <rect x="300" y="40" width="12" height="240" fill="#E0DDD7" stroke="#141414" strokeWidth="1.5" />
                <rect x="330" y="40" width="12" height="240" fill="#E0DDD7" stroke="#141414" strokeWidth="1.5" />
                <rect x="700" y="40" width="30" height="240" fill="#E0DDD7" stroke="#141414" strokeWidth="2.5" />

                {/* Overhanging Modernist Cantilever Balconies */}
                <path d="M 400 80 L 640 80 L 640 100 L 410 100 L 390 140 L 360 140 Z" fill="#D4D1CA" stroke="#141414" strokeWidth="2" />
                <path d="M 400 160 L 640 160 L 640 180 L 410 180 L 390 220 L 360 220 Z" fill="#D4D1CA" stroke="#141414" strokeWidth="2" />

                {/* Diagonal Breeze Brick Ventilation Block Wall Layer */}
                <g stroke="#141414" strokeWidth="1.5" fill="none">
                  {/* Ventilation Slots mapping letters */}
                  <rect x="130" y="60" width="30" height="30" /> <circle cx="145" cy="75" r="8" />
                  <rect x="130" y="100" width="30" height="30" /> <circle cx="145" cy="115" r="8" />
                  <rect x="130" y="140" width="30" height="30" /> <circle cx="145" cy="155" r="8" />
                  <rect x="130" y="180" width="30" height="30" /> <circle cx="145" cy="195" r="8" />
                  <rect x="130" y="220" width="30" height="30" /> <circle cx="145" cy="235" r="8" />

                  <rect x="170" y="60" width="30" height="30" /> <path d="M 175 75 H 195 M 185 65 V 85" />
                  <rect x="170" y="100" width="30" height="30" /> <path d="M 175 115 H 195 M 185 105 V 125" />
                  <rect x="170" y="140" width="30" height="30" /> <path d="M 175 155 H 195 M 185 145 V 165" />
                  <rect x="170" y="180" width="30" height="30" /> <path d="M 175 195 H 195 M 185 185 V 205" />
                  <rect x="170" y="220" width="30" height="30" /> <path d="M 175 235 H 195 M 185 225 V 245" />
                </g>

                {/* Airflow / Thermal Vector lines (Muted Orange Vectors) */}
                <g stroke={accentTheme === "moss" ? "#4A5D4E" : "#C85C42"} strokeWidth="2" strokeDasharray="3 3">
                  {/* Air cooling drafts filtering through breeze blocks */}
                  <path d="M 230 75 Q 190 75 110 75" />
                  <path d="M 230 155 Q 190 155 110 155" />
                  <path d="M 230 235 Q 190 235 110 235" />

                  {/* Hot exhaust exiting upward from cantilever balconies */}
                  <path d="M 620 120 Q 580 120 540 60" />
                  <path d="M 620 200 Q 580 200 540 140" />
                </g>

                {/* Data Trajectory Core Pipelines descending into bedrock */}
                <g stroke="#141414" strokeWidth="2" fill="none">
                  {/* Dynamic Nodes representing Cache, Trace, Mem */}
                  <circle cx="500" cy="90" r="14" fill={accentTheme === "moss" ? "#4A5D4E" : "#C85C42"} />
                  <text x="500" y="93" fill="white" fontSize="9" fontFamily="monospace" textAnchor="middle" fontWeight="bold">CACHE</text>
                  
                  <circle cx="480" cy="170" r="14" fill="#141414" />
                  <text x="480" y="173" fill="white" fontSize="9" fontFamily="monospace" textAnchor="middle" fontWeight="bold">TRACE</text>

                  <rect x="440" y="235" width="60" height="24" fill="#A1A1A1" stroke="#141414" strokeWidth="2" />
                  <text x="470" y="249" fill="white" fontSize="8" fontFamily="monospace" textAnchor="middle" fontWeight="bold">MEM_BED</text>

                  {/* Pipelines connection */}
                  <path d="M 500 104 Q 490 135 480 156" arrow-start="true" strokeDasharray="4 2" />
                  <path d="M 480 184 L 470 235" strokeDasharray="4 2" />
                </g>

                {/* Legend Labels */}
                <g fontSize="8" fontFamily="monospace" fill="#A1A1A1">
                  <text x="80" y="30" textAnchor="middle">1. MAIN ANCHOR STRUT</text>
                  <text x="170" y="30" textAnchor="middle">2. BREEZE BRICK GRILLES</text>
                  <text x="550" y="66">3. CANTILEVER DEFLECTOR BARS</text>
                  <text x="400" y="315">4. EXTREME LATENCY GRAVITATIONAL DRAINPIPE</text>
                </g>

              </svg>
            </div>
          </div>

          {/* DYNAMIC SECTION 5: ECOSYSTEM & PLATFORM ROADMAP (REAL MILESTONES) */}
          <div className="border-4 border-[#141414] bg-[#F5F2ED] p-6 md:p-8 relative shadow-tropical">
            <div className="mb-6">
              <span className={`font-mono text-xs text-white ${accentBg} px-2 py-0.5 tracking-wider uppercase transition-all duration-200`}>Project Status</span>
              <h3 className="font-sans font-black text-2xl tracking-tight text-[#141414] mt-1">Status & Real-World Roadmap</h3>
              <p className="text-xs text-neutral-600 mt-1">We track milestones strictly. Do not invent funding, claims, or production assertions. Under construction.</p>
            </div>

            <div className="border-2 border-[#141414] overflow-x-auto shadow-sm">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-[#141414] text-[#F5F2ED] uppercase text-[10px]">
                    <th className="p-3 border-b-2 border-[#141414]">MILESTONE ID</th>
                    <th className="p-3 border-b-2 border-[#141414]">CODE COMPONENT</th>
                    <th className="p-3 border-b-2 border-[#141414]">STRUCTURAL DESCRIPTION</th>
                    <th className="p-3 border-b-2 border-[#141414]">METRIC TARGET</th>
                    <th className="p-3 border-b-2 border-[#141414]">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#141414] bg-[#F5F2ED]">
                  <tr>
                    <td className="p-3 font-bold bg-[#E0DDD7]/40">SAI_PHASE_01</td>
                    <td className="p-3 font-sans font-bold text-[#141414]">CachePawl Core</td>
                    <td className="p-3 text-neutral-700">Compile semantic vector buffers on raw isolated RAM pools in Southeast Asia Cloud centers.</td>
                    <td className={`p-3 font-bold ${accentText} transition-all duration-200`}>&lt; 14ms routing</td>
                    <td className="p-3 text-emerald-700 font-bold">● COMPLETE</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#E0DDD7]/40">SAI_PHASE_02</td>
                    <td className="p-3 font-sans font-bold text-[#141414]">TracePawl Core</td>
                    <td className="p-3 text-neutral-700">Drafting deterministic step triggers that capture external API side-effects of async execution chains safely.</td>
                    <td className="p-3 font-bold text-[#141414]">100% replay accuracy</td>
                    <td className="p-3 text-amber-700 font-bold">◌ ACTIVE DESIGN</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#E0DDD7]/40">SAI_PHASE_03</td>
                    <td className="p-3 font-sans font-bold text-[#141414]">MemPawl Router</td>
                    <td className="p-3 text-neutral-700">Hierarchical storage router marrying hot PostgreSQL memory structures to deep cold flat storage pools.</td>
                    <td className="p-3 font-bold text-neutral-400">TODO Placeholder</td>
                    <td className="p-3 text-neutral-500 font-bold">◌ TODO LISTED</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#E0DDD7]/40">SAI_PHASE_04</td>
                    <td className="p-3 font-sans font-bold text-[#141414]">TrainPawl Compiler</td>
                    <td className="p-3 text-neutral-700">LoRA compilation loops translating execution trajectories directly into fine-tuning datasets for tiny runtimes.</td>
                    <td className="p-3 font-bold text-neutral-400">TODO Placeholder</td>
                    <td className="p-3 text-neutral-500 font-bold">◌ TODO LISTED</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </section>

        {/* RIGHT COLUMN: BRAND MATRIX BRIEF & IMPLEMENTATION HANDOFF (4 COLS) */}
        <aside className="lg:col-span-4 flex flex-col gap-8">
          
          {/* THE BRAND BRIEF IDENTITY CARD (IMMEDIATELY SOLVES USER TARGETS) */}
          <div className="border-4 border-[#141414] bg-[#F5F2ED] p-6 relative shadow-tropical-sm">
            <span className={`font-mono text-xs ${accentText} tracking-widest font-bold uppercase block mb-1 transition-all duration-200`}>
              BRAND BRIEF IDENTITY
            </span>
            <h2 className="font-sans font-black text-2xl tracking-tighter text-[#141414]">
              {inputsData.brand.name}
            </h2>
            <span className="font-mono text-[10px] text-neutral-500 block uppercase tracking-wide">
              VN ARCH_METAPHOR × DEV TOOLING
            </span>

            <p className="font-sans text-xs text-neutral-600 mt-4 leading-relaxed">
              {inputsData.brand.description}
            </p>

            <div className="mt-5 border-t border-[#141414]/15 pt-4 flex flex-col gap-3">
              <div>
                <span className="text-[10px] font-mono text-neutral-500 block uppercase">ARCHITECTURAL LANGUAGE</span>
                <span className="text-xs font-sans font-extrabold text-[#141414]">
                  {inputsData.aesthetic.style}
                </span>
              </div>

              <div>
                <span className="text-[10px] font-mono text-neutral-500 block uppercase">GUIDING MOOD</span>
                <p className="text-xs text-neutral-600 italic leading-snug">
                  Technical, architectural, credible, experimental, serious, Vietnamese without nostalgia, brutalist without chaos.
                </p>
              </div>

              <div>
                <span className="text-[10px] font-mono text-neutral-500 block uppercase">CORE MISSION STATEMENT</span>
                <p className="text-xs text-neutral-600 leading-normal">
                  {inputsData.brand.mission}
                </p>
              </div>
            </div>
          </div>

          {/* BLUEPRINT BRIEF INSPECTOR (LIVE VIEW/EDIT OF INPUTS.JSON) */}
          <div className="border-4 border-[#141414] bg-[#E0DDD7] p-6 relative shadow-tropical-sm">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-1.5">
                <FileText className={`w-4 h-4 ${accentText}`} />
                <span className="font-mono text-xs text-[#141414] font-black uppercase">
                  inputs.json Inspector
                </span>
              </div>
              <button 
                onClick={() => setShowMetadataRaw(!showMetadataRaw)}
                className="font-mono text-[9px] border border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-colors cursor-pointer"
              >
                {showMetadataRaw ? "COLLAPSE" : "INSPECT RAW"}
              </button>
            </div>

            <p className="text-[11px] text-neutral-600 mb-4 leading-normal">
              CodePawl parses this typed manifest locally to establish dynamic UI component constraints.
            </p>

            {showMetadataRaw ? (
              <div className="relative">
                <button
                  onClick={() => handleCopyClipboard(JSON.stringify(inputsData, null, 2), "inputs_json")}
                  className="absolute right-2 top-2 bg-white/85 border border-[#141414] text-[#141414] text-[8px] font-mono px-1.5 py-0.5 cursor-pointer hover:bg-[#141414] hover:text-white transition-all"
                >
                  {copiedText === "inputs_json" ? "COPIED" : "COPY"}
                </button>
                <pre className="text-[9px] font-mono bg-[#141414] text-slate-350 p-4 border border-[#141414] max-h-[300px] overflow-auto whitespace-pre">
                  {JSON.stringify(inputsData, null, 2)}
                </pre>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {/* Structural list elements check list */}
                <span className="text-[9px] font-mono text-neutral-500 uppercase block tracking-wider">
                  ARCHITECTURAL TOKENS APPLIED
                </span>
                <div className="flex flex-col gap-2">
                  <div className="bg-[#F5F2ED] p-3 text-xs border border-[#141414]">
                    <span className={`font-mono text-[10px] ${accentText} block font-bold transition-all duration-200`}>Ventilation Blocks (Gạch Bông Gió)</span>
                    <span className="text-[11px] text-neutral-600 leading-snug mt-0.5 block">Configurable pattern grids mapping cooling and latency properties with modular air draft parameters.</span>
                  </div>
                  <div className="bg-[#F5F2ED] p-3 text-xs border border-[#141414]">
                    <span className={`font-mono text-[10px] ${accentText} block font-bold transition-all duration-200`}>Concrete Fins & Shadows</span>
                    <span className="text-[11px] text-neutral-600 leading-snug mt-0.5 block">Tropical shade limits built utilizing high-contrast vertical borders and repeating diagonal background louvers.</span>
                  </div>
                  <div className="bg-[#F5F2ED] p-3 text-xs border border-[#141414]">
                    <span className={`font-mono text-[10px] ${accentText} block font-bold transition-all duration-200`}>Asymmetrical Block Overhangs</span>
                    <span className="text-[11px] text-neutral-600 leading-snug mt-0.5 block">Clean structural margins dividing raw component views statically. No unrequested overlapping or chaotic gradients.</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* WEB REPO IMPLEMENTATION HANDOFF BOX */}
          <div className="border-4 border-[#141414] bg-[#141414] text-[#F5F2ED] p-6 relative shadow-tropical-sm">
            <span className={`font-mono text-xs ${accentText} tracking-widest block uppercase font-bold mb-1 transition-all duration-200`}>
              COUPAL ASSEMBLY METRICS
            </span>
            <h3 className="font-sans font-black text-xl text-white tracking-tight">
              Implementation Handoff
            </h3>
            <p className="text-[10px] text-neutral-400 leading-normal mt-1 mb-4">
              Pristine tokens list prepared for later integration in the target production code repository.
            </p>

            <div className="flex flex-col gap-4 text-xs font-mono max-h-[300px] overflow-y-auto">
              <div>
                <span className={`scale-y-95 font-bold ${accentText} block uppercase text-[10px] transition-all duration-200`}>Aesthetic Selection Rationale</span>
                <span className="text-neutral-300 block text-[11px] font-sans mt-0.5 leading-normal">
                  Chose Southern Vietnamese Modernism characterized by climate-responsive passive shielding. Fits CodePawl&apos;s goal of high reliability and thermal efficiency under severe multi-agent concurrency loads.
                </span>
              </div>

              <div>
                <span className={`scale-y-95 font-bold ${accentText} block uppercase text-[10px] transition-all duration-200`}>Pristine Design Tokens</span>
                <div className="bg-neutral-900 border border-white/10 p-2.5 mt-1 text-[10px] space-y-1">
                  <div>- <span className="text-white">bg-primary</span>: #F5F2ED (High Density Cream)</div>
                  <div>- <span className="text-white">bg-secondary</span>: #EAE7E1 / #E0DDD7 (High Density Concrete)</div>
                  <div>- <span className="text-white">color-accent</span>: #4A5D4E (Moss) / #C85C42 (Sienna)</div>
                  <div>- <span className="text-white">font-sans</span>: Inter + Space Grotesk displays</div>
                  <div>- <span className="text-white">font-mono</span>: JetBrains Mono (For telemetry variables)</div>
                </div>
              </div>

              <div>
                <span className={`scale-y-95 font-bold ${accentText} block uppercase text-[10px] transition-all duration-200`}>Platform Risk Mitigations</span>
                <ul className="list-disc list-inside space-y-1 text-neutral-300 text-[10px] mt-1 pl-1">
                  <li>Pre-computes static ventilation vectors inside raw SVGs to bypass heavy layout reflow calculations.</li>
                  <li>Maintains high accessibility thresholds by bounding deep text with warm High Density cream backings.</li>
                  <li>Forces single-column content stack patterns under 1024px screen widths to avoid complex drawer overflows.</li>
                </ul>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex justify-between">
              <span className="text-[9px] font-mono text-neutral-400">HANDOFF BLUEPRINT // APPLIED</span>
              <BookOpen className={`w-4 h-4 ${accentText} transition-all duration-200`} />
            </div>
          </div>

        </aside>

      </div>

      {/* FOOTER AREA - TECHNICAL BRUTAL DESCRIPTION */}
      <footer className="w-full border-t-4 border-[#141414] bg-[#EAE7E1] py-12 px-6 mt-16 z-10 text-[#141414]">
        <div className="max-w-[1360px] mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          <div className="md:col-span-4 flex flex-col gap-3">
            <h4 className="font-sans font-black tracking-tight text-xl">CODEPAWL</h4>
            <span className="font-mono text-[10px] text-neutral-500 uppercase">
              KIÊN TRÚC NHÂN — AI CONCRETE CONTEXT LOOM
            </span>
            <p className="text-xs text-neutral-600 leading-relaxed mt-2">
              A serious, functional exploration coupling South Vietnamese Modernist Architectural structures with highly-efficient, deterministic AI agent processing runtimes. Generated with pristine mathematical precision.
              Designed under high structural density rules.
            </p>
          </div>

          <div className="md:col-span-4 flex flex-col gap-2 text-xs font-mono text-neutral-750">
            <span className={`uppercase font-bold tracking-wider ${accentText} transition-all duration-200`}>PROJECT GEOMETRIC ORIGINS</span>
            <div>- Location: District 3, Ho Chi Minh City, Vietnam</div>
            <div>- Coordinates: 10.7769° N, 106.6953° E (WGS 84)</div>
            <div>- Thermal Context Style: Louvered breeze bricks + passive cooling channels</div>
            <div>- Real-world Status: Active research playground repository template</div>
          </div>

          <div className="md:col-span-4 flex flex-col gap-3 text-xs text-neutral-500 font-mono">
            <div className="border border-[#141414] bg-[#D4D1CA] p-3 text-[10px] text-[#141414]">
              <span className="font-bold uppercase block mb-1">LICENSE STATUS NOTE:</span>
              Design concept prototypes presented here represent static architectural references. Code execution structures are subject to sandbox execution rules. Under Construction.
            </div>
            <span>© 2026 CodePawl. Built with Vietnamese modernism.</span>
          </div>

        </div>
      </footer>

    </main>
  );
}
